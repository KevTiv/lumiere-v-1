// Auto-generated from ir/agent-capability-registry-v1.json. Do not edit.
export type AgentCapabilityRisk =
  | "read_only"
  | "presentation"
  | "draft"
  | "business_mutation"
  | "financial_mutation"

export type AgentCapabilityResultPolicy =
  | { readonly kind: "direct"; readonly max_bytes: number }
  | { readonly kind: "dataset"; readonly max_rows: number; readonly max_bytes: number }
  | { readonly kind: "aggregate_first"; readonly allowed_shapes: readonly string[]; readonly max_output_rows: number }

export type AgentCapabilityReview = {
  readonly reviewed_by: string
  readonly reviewed_at: string
  readonly evidence: string
}

/** Present only for entries the release can advertise to a model. */
export type AgentCapabilityTool = {
  readonly name: string
  readonly description: string
  readonly input_schema: Record<string, unknown>
}

export type AgentCapabilityEntry = {
  readonly operation_id?: string
  readonly resource?: string
  readonly capability_key: string
  readonly risk: AgentCapabilityRisk
  readonly requires_confirmation: boolean
  readonly result_policy: AgentCapabilityResultPolicy
  readonly review: AgentCapabilityReview
  readonly tool?: AgentCapabilityTool
  readonly operation?: Record<string, unknown>
  readonly resource_descriptor?: Record<string, unknown>
}

export type AgentCapabilityRegistryV1 = {
  readonly artifact_version: 2
  readonly source_ir: {
    readonly ir_version: 2
    readonly source_commit: string
    readonly source_dirty: false
    readonly schema_hash: string
  }
  readonly entries: readonly AgentCapabilityEntry[]
}

export const AGENT_CAPABILITY_REGISTRY_V1 = {
  "artifact_version": 2,
  "entries": [
    {
      "capability_key": "inventory.products.read",
      "requires_confirmation": false,
      "resource": "products",
      "resource_descriptor": {
        "contract": {
          "aliases": [
            "products",
            "product"
          ],
          "default_restricted": [
            "name",
            "display_name",
            "code",
            "default_code",
            "active",
            "categ_id",
            "list_price",
            "public_price",
            "type",
            "barcode",
            "purchase_ok",
            "tracking"
          ],
          "mandatory": [
            "id",
            "organization_id",
            "uom_id",
            "uom_po_id"
          ],
          "table": "product"
        },
        "query": {
          "authorization": "server-enforced",
          "cursor_type_reference": null,
          "filter_type_reference": null,
          "input_type_reference": null,
          "result_type_reference": "Product",
          "status": "classified"
        },
        "resource_name": "products",
        "row": {
          "type_reference": "Product"
        },
        "scope": {
          "company_field": null,
          "identity_field": null,
          "kind": "organization",
          "organization_field": "organization_id",
          "resolution": "direct",
          "source": "subscription_census"
        },
        "source": {
          "kind": "table",
          "table_reference": "product"
        },
        "subscription": {
          "access_path": {
            "exception": "SQ-0 records the resource shape; SQ-2 must map interactive reads to a shared STDB access path.",
            "key": null,
            "status": "pending"
          },
          "delivery_mode": "invalidation-only",
          "expected_cardinality": "broad",
          "latency_class": "interactive",
          "predicate_class": "none",
          "query_plan": {
            "order_by": [],
            "predicates": [],
            "table": "product"
          },
          "realtime": true,
          "reconnect_class": "eager",
          "source_class": "canonical-table",
          "status": "classified",
          "update_fanout": "medium"
        }
      },
      "result_policy": {
        "kind": "dataset",
        "max_bytes": 65536,
        "max_rows": 100
      },
      "review": {
        "evidence": "Read already performed by the promoted low_stock skill through raw SQL on the product table; exposing it as a reviewed capability narrows rather than widens reach. Row ceiling matches that skill's accepted 100-row limit.",
        "reviewed_at": "2026-09-13T00:00:00Z",
        "reviewed_by": "KevTiv"
      },
      "risk": "read_only",
      "tool": {
        "description": "Read authorized products rows (Product in table product). Scope is server-derived and field access is enforced per actor. Reviewed by KevTiv: Read already performed by the promoted low_stock skill through raw SQL on the product table; exposing it as a reviewed capability narrows rather than widens reach. Row ceiling matches that skill's accepted 100-row limit.",
        "input_schema": {
          "additionalProperties": false,
          "properties": {
            "max_rows": {
              "description": "Rows to request, capped by the reviewed ceiling and the actor's role policy.",
              "maximum": 100,
              "minimum": 1,
              "type": "integer"
            }
          },
          "required": [],
          "type": "object"
        },
        "name": "inventory_products_read"
      }
    },
    {
      "capability_key": "inventory.stock-locations.read",
      "requires_confirmation": false,
      "resource": "stock-locations",
      "resource_descriptor": {
        "contract": {
          "aliases": [
            "stock-locations",
            "stock_location"
          ],
          "default_restricted": [
            "name",
            "usage",
            "complete_name",
            "company_id",
            "location_id"
          ],
          "mandatory": [
            "id",
            "organization_id"
          ],
          "table": "stock_location"
        },
        "query": {
          "authorization": "server-enforced",
          "cursor_type_reference": null,
          "filter_type_reference": null,
          "input_type_reference": null,
          "result_type_reference": "StockLocation",
          "status": "classified"
        },
        "resource_name": "stock-locations",
        "row": {
          "type_reference": "StockLocation"
        },
        "scope": {
          "company_field": "company_id",
          "identity_field": null,
          "kind": "organization_company",
          "organization_field": "organization_id",
          "resolution": "direct",
          "source": "subscription_census"
        },
        "source": {
          "kind": "table",
          "table_reference": "stock_location"
        },
        "subscription": {
          "access_path": {
            "exception": "SQ-0 records the resource shape; SQ-2 must map interactive reads to a shared STDB access path.",
            "key": null,
            "status": "pending"
          },
          "delivery_mode": "invalidation-only",
          "expected_cardinality": "broad",
          "latency_class": "interactive",
          "predicate_class": "none",
          "query_plan": {
            "order_by": [],
            "predicates": [],
            "table": "stock_location"
          },
          "realtime": true,
          "reconnect_class": "eager",
          "source_class": "canonical-table",
          "status": "classified",
          "update_fanout": "medium"
        }
      },
      "result_policy": {
        "kind": "dataset",
        "max_bytes": 65536,
        "max_rows": 100
      },
      "review": {
        "evidence": "Needed to name the location behind a stock quantity in an answer. Company-scoped read with server-enforced authorization; no pricing, cost or personal fields.",
        "reviewed_at": "2026-09-13T00:00:00Z",
        "reviewed_by": "KevTiv"
      },
      "risk": "read_only",
      "tool": {
        "description": "Read authorized stock-locations rows (StockLocation in table stock_location). Scope is server-derived and field access is enforced per actor. Reviewed by KevTiv: Needed to name the location behind a stock quantity in an answer. Company-scoped read with server-enforced authorization; no pricing, cost or personal fields.",
        "input_schema": {
          "additionalProperties": false,
          "properties": {
            "company_id": {
              "description": "Company to read within the authorized organization; verified server-side.",
              "minimum": 1,
              "type": "integer"
            },
            "max_rows": {
              "description": "Rows to request, capped by the reviewed ceiling and the actor's role policy.",
              "maximum": 100,
              "minimum": 1,
              "type": "integer"
            }
          },
          "required": [],
          "type": "object"
        },
        "name": "inventory_stock_locations_read"
      }
    },
    {
      "capability_key": "inventory.stock-quants.read",
      "requires_confirmation": false,
      "resource": "stock-quants",
      "resource_descriptor": {
        "contract": {
          "aliases": [
            "stock-quants",
            "stock_quant"
          ],
          "default_restricted": [
            "product_id",
            "location_id",
            "quantity",
            "reserved_quantity",
            "available_quantity",
            "company_id",
            "lot_id",
            "package_id",
            "owner_id"
          ],
          "mandatory": [
            "id",
            "organization_id"
          ],
          "table": "stock_quant"
        },
        "query": {
          "authorization": "server-enforced",
          "cursor_type_reference": null,
          "filter_type_reference": null,
          "input_type_reference": null,
          "result_type_reference": "StockQuant",
          "status": "classified"
        },
        "resource_name": "stock-quants",
        "row": {
          "type_reference": "StockQuant"
        },
        "scope": {
          "company_field": "company_id",
          "identity_field": null,
          "kind": "organization_company",
          "organization_field": "organization_id",
          "resolution": "direct",
          "source": "subscription_census"
        },
        "source": {
          "kind": "table",
          "table_reference": "stock_quant"
        },
        "subscription": {
          "access_path": {
            "exception": "SQ-0 records the resource shape; SQ-2 must map interactive reads to a shared STDB access path.",
            "key": null,
            "status": "pending"
          },
          "delivery_mode": "invalidation-only",
          "expected_cardinality": "broad",
          "latency_class": "interactive",
          "predicate_class": "none",
          "query_plan": {
            "order_by": [],
            "predicates": [],
            "table": "stock_quant"
          },
          "realtime": true,
          "reconnect_class": "staggered",
          "source_class": "canonical-table",
          "status": "classified",
          "update_fanout": "high"
        }
      },
      "result_policy": {
        "kind": "dataset",
        "max_bytes": 65536,
        "max_rows": 100
      },
      "review": {
        "evidence": "Read already performed by the promoted low_stock skill through raw SQL on the stock_quant table. Quantities only, company-scoped, no valuation fields.",
        "reviewed_at": "2026-09-13T00:00:00Z",
        "reviewed_by": "KevTiv"
      },
      "risk": "read_only",
      "tool": {
        "description": "Read authorized stock-quants rows (StockQuant in table stock_quant). Scope is server-derived and field access is enforced per actor. Reviewed by KevTiv: Read already performed by the promoted low_stock skill through raw SQL on the stock_quant table. Quantities only, company-scoped, no valuation fields.",
        "input_schema": {
          "additionalProperties": false,
          "properties": {
            "company_id": {
              "description": "Company to read within the authorized organization; verified server-side.",
              "minimum": 1,
              "type": "integer"
            },
            "max_rows": {
              "description": "Rows to request, capped by the reviewed ceiling and the actor's role policy.",
              "maximum": 100,
              "minimum": 1,
              "type": "integer"
            }
          },
          "required": [],
          "type": "object"
        },
        "name": "inventory_stock_quants_read"
      }
    }
  ],
  "source_ir": {
    "ir_version": 2,
    "schema_hash": "sha256:b241ea027fe717d1ad106420088f21d63de02fd57feb47bb3b36ab5091074f0d",
    "source_commit": "59ab3cbc083088f40633961bfd28a492bf3bc3cc",
    "source_dirty": false
  }
} as const satisfies AgentCapabilityRegistryV1

export const AGENT_CAPABILITIES = AGENT_CAPABILITY_REGISTRY_V1.entries

export function findAgentCapability(capabilityKey: string): AgentCapabilityEntry | undefined {
  return (AGENT_CAPABILITIES as readonly AgentCapabilityEntry[]).find(
    (entry) => entry.capability_key === capabilityKey,
  )
}
