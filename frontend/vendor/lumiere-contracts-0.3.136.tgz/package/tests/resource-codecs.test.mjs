import assert from "node:assert/strict"
import test from "node:test"

import {
  ResourceQueryRowDecodeError,
  decodeResourceQueryRow,
} from "../dist/generated/resource-codecs.js"

test("decodes mandatory company projection fields losslessly", () => {
  const row = decodeResourceQueryRow("companies", {
    id: "18446744073709551615",
    organizationId: 7,
  })
  assert.equal(row.id, 18446744073709551615n)
  assert.equal(row.organizationId, 7n)
})

test("decodes authorized optional account projection fields from IR", () => {
  const row = decodeResourceQueryRow("account-accounts", {
    id: "41",
    organizationId: 7,
    internalType: "Asset",
    allowedJournalIds: ["2", 3],
    createDate: { microsSinceUnixEpoch: "1781987714525004" },
  })
  assert.deepEqual(row.internalType, { tag: "Asset" })
  assert.deepEqual(row.allowedJournalIds, [2n, 3n])
  assert.equal(row.createDate?.microsSinceUnixEpoch, 1781987714525004n)
})

test("decodes generated journal and tax projection fields", () => {
  const journalIdentity = "01".repeat(32)
  const journal = decodeResourceQueryRow("account-journals", {
    id: 5,
    organizationId: "7",
    type: "Bank",
    defaultAccountId: null,
    createUid: journalIdentity,
    createDate: { microsSinceUnixEpoch: "1781987714525004" },
    dedicatedPaymentMethodIds: ["2", 3],
  })
  assert.deepEqual(journal.type, { tag: "Bank" })
  assert.equal(journal.defaultAccountId, undefined)
  assert.equal(journal.createUid?.toHexString(), journalIdentity)
  assert.equal(journal.createDate?.microsSinceUnixEpoch, 1781987714525004n)
  assert.deepEqual(journal.dedicatedPaymentMethodIds, [2n, 3n])

  const taxIdentity = "02".repeat(32)
  const tax = decodeResourceQueryRow("account-taxes", {
    id: "6",
    organizationId: 7,
    amount: 21,
    typeTaxUse: "Sale",
    amountType: "Percent",
    createUid: taxIdentity,
    createDate: { microsSinceUnixEpoch: "1781987714525005" },
    invoiceRepartitionLineIds: ["8", 9],
  })
  assert.equal(tax.id, 6n)
  assert.deepEqual(tax.typeTaxUse, { tag: "Sale" })
  assert.deepEqual(tax.amountType, { tag: "Percent" })
  assert.equal(tax.createUid?.toHexString(), taxIdentity)
  assert.equal(tax.createDate?.microsSinceUnixEpoch, 1781987714525005n)
  assert.deepEqual(tax.invoiceRepartitionLineIds, [8n, 9n])
})

test("decodes projected account move lines without inventing hidden fields", () => {
  const line = decodeResourceQueryRow("account-move-lines", {
    id: "8",
    organizationId: 7,
    moveId: "13",
    companyId: 42,
    date: { microsSinceUnixEpoch: "1781987714525006" },
    name: "Receivable",
    debit: 125.5,
    credit: 0,
    balance: 125.5,
    accountId: "1100",
    partnerId: null,
  })
  assert.equal(line.id, 8n)
  assert.equal(line.moveId, 13n)
  assert.equal(line.companyId, 42n)
  assert.equal(line.date?.microsSinceUnixEpoch, 1781987714525006n)
  assert.equal(line.accountId, 1100n)
  assert.equal(line.partnerId, undefined)

  assert.deepEqual(
    decodeResourceQueryRow("account-move-lines", { id: 9, organizationId: 7 }),
    { id: 9n, organizationId: 7n },
  )
})

test("decodes projected account moves and their enum and timestamp fields", () => {
  const move = decodeResourceQueryRow("account-moves", {
    id: "21",
    organizationId: 7,
    name: "INV/2026/0021",
    moveType: "OutInvoice",
    state: "Posted",
    date: { microsSinceUnixEpoch: "1781987714525007" },
    companyId: 42,
    journalId: "5",
    partnerId: null,
    currencyId: 1,
    invoiceDate: null,
    amountUntaxed: 100,
    amountTax: 21,
    amountTotal: 121,
    amountResidual: 40,
    paymentState: "Partial",
    metadata: null,
  })
  assert.equal(move.id, 21n)
  assert.deepEqual(move.moveType, { tag: "OutInvoice" })
  assert.deepEqual(move.state, { tag: "Posted" })
  assert.equal(move.date?.microsSinceUnixEpoch, 1781987714525007n)
  assert.equal(move.partnerId, undefined)
  assert.equal(move.invoiceDate, undefined)
  assert.deepEqual(move.paymentState, { tag: "Partial" })

  assert.deepEqual(
    decodeResourceQueryRow("account-moves", { id: 22, organizationId: 7 }),
    { id: 22n, organizationId: 7n },
  )
})

test("decodes shared and company-owned account type projections", () => {
  const shared = decodeResourceQueryRow("account-account-types", {
    id: "31",
    organizationId: 7,
    name: "Receivable",
    type: "receivable",
    internalGroup: "Asset",
    companyId: null,
    includeInitialBalance: true,
    isDeprecated: false,
  })
  assert.equal(shared.id, 31n)
  assert.deepEqual(shared.internalGroup, { tag: "Asset" })
  assert.equal(shared.companyId, undefined)

  const owned = decodeResourceQueryRow("account-account-types", {
    id: 32,
    organizationId: "7",
    companyId: "42",
  })
  assert.equal(owned.companyId, 42n)
})

test("decodes additional accounting projections from the generated resource graph", () => {
  const group = decodeResourceQueryRow("account-groups", {
    id: "41",
    organizationId: 7,
    companyId: "42",
    level: 2,
  })
  assert.equal(group.id, 41n)
  assert.equal(group.companyId, 42n)
  assert.equal(group.level, 2)

  const transaction = decodeResourceQueryRow("payment-transactions", {
    id: "51",
    organizationId: 7,
    companyId: 42,
  })
  assert.equal(transaction.id, 51n)
  assert.equal(transaction.companyId, 42n)
})

test("fails closed for missing mandatory and unknown fields", () => {
  assert.throws(
    () => decodeResourceQueryRow("account-accounts", { id: 1 }),
    ResourceQueryRowDecodeError,
  )
  assert.throws(
    () => decodeResourceQueryRow("companies", {
      id: 1,
      organizationId: 7,
      credentialReference: "secret",
    }),
    /unknown field credentialReference/,
  )
  assert.throws(
    () => decodeResourceQueryRow("account-taxes", {
      id: 1,
      organizationId: 7,
      amountType: "Unsupported",
    }),
    /unknown enum tag/,
  )
  assert.throws(
    () => decodeResourceQueryRow("account-move-lines", {
      id: 1,
      organizationId: 7,
      credentialReference: "secret",
    }),
    /unknown field credentialReference/,
  )
  assert.throws(
    () => decodeResourceQueryRow("account-moves", {
      id: 1,
      organizationId: 7,
      state: "Unknown",
    }),
    /unknown enum tag/,
  )
  assert.throws(
    () => decodeResourceQueryRow("account-account-types", {
      id: 1,
      organizationId: 7,
      internalGroup: "Unsupported",
    }),
    /unknown enum tag/,
  )
})
