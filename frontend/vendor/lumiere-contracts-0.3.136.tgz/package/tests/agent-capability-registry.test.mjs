import assert from "node:assert/strict"
import test from "node:test"

import {
  AGENT_CAPABILITIES,
  AGENT_CAPABILITY_REGISTRY_V1,
  findAgentCapability,
} from "../dist/generated/agent-capability-registry.js"

test("exports a source-bound deny-by-default capability registry", () => {
  assert.equal(AGENT_CAPABILITY_REGISTRY_V1.artifact_version, 2)
  assert.equal(AGENT_CAPABILITY_REGISTRY_V1.source_ir.ir_version, 2)
  assert.equal(AGENT_CAPABILITY_REGISTRY_V1.source_ir.source_dirty, false)
  assert.match(AGENT_CAPABILITY_REGISTRY_V1.source_ir.source_commit, /^[0-9a-f]{40}$/)
  assert.deepEqual(
    AGENT_CAPABILITIES.map(({ capability_key }) => capability_key),
    [
      "inventory.products.read",
      "inventory.stock-locations.read",
      "inventory.stock-quants.read",
    ],
  )
  for (const capability of AGENT_CAPABILITIES) {
    assert.equal(capability.risk, "read_only")
    assert.equal(capability.requires_confirmation, false)
    assert.ok(capability.review.reviewed_by)
    assert.ok(capability.review.reviewed_at)
    assert.ok(capability.review.evidence)
    assert.equal(capability.tool.input_schema.additionalProperties, false)
    assert.equal(capability.tool.input_schema.properties.organization_id, undefined)
  }
  assert.equal(
    findAgentCapability("inventory.products.read")?.resource,
    "products",
  )
  assert.equal(findAgentCapability("missing"), undefined)
})
