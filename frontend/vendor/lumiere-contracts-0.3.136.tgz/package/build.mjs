import { readdir, readFile, rm, writeFile } from "node:fs/promises"
import { extname, join } from "node:path"
import { spawnSync } from "node:child_process"

await rm("dist", { recursive: true, force: true })

const compiler = process.platform === "win32" ? "node_modules/.bin/tsc.cmd" : "node_modules/.bin/tsc"
const result = spawnSync(
  compiler,
  ["-p", "tsconfig.json", "--noEmit", "false", "--outDir", "dist", "--rootDir", "src"],
  { stdio: "inherit" },
)
if (result.status !== 0) process.exit(result.status ?? 1)

async function emittedJavaScript(directory) {
  const files = []
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name)
    if (entry.isDirectory()) files.push(...await emittedJavaScript(path))
    else if (entry.name.endsWith(".js")) files.push(path)
  }
  return files
}

// TypeScript preserves the generator's extensionless relative imports. Add the
// emitted `.js` suffix so the installed package also works in strict Node ESM.
for (const file of await emittedJavaScript("dist")) {
  const source = await readFile(file, "utf8")
  const rewritten = source.replace(
    /(from\s+["']|import\s*["'])(\.\.?\/[^"']+)(["'])/g,
    (match, prefix, specifier, quote) =>
      extname(specifier) ? match : `${prefix}${specifier}.js${quote}`,
  )
  if (rewritten !== source) await writeFile(file, rewritten)
}
